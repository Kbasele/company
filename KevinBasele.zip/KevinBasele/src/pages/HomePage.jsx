import React from 'react'
import CustomerListItem from '../components/CustomerListItem'

export default function HomePage() {
    return (
        <div>
            <CustomerListItem />
        </div>
    )
}
