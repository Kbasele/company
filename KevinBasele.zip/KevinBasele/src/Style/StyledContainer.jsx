import styled from 'styled-components'

export const StyledContainer = styled.div`
    display: flex; 
    .main-content{
        height: 100vh; 
        width: 85vw; 
    }

`